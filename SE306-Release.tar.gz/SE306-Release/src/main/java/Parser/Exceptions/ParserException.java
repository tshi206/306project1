package Parser.Exceptions;

/**
 * Created by e on 28/07/17.
 */
public class ParserException extends Exception {
    public ParserException(String s) {
        super(s);
    }

    public ParserException() {
    }
}
