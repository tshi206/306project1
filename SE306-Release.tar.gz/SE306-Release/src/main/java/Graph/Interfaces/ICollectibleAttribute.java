package Graph.Interfaces;

import java.util.Map;

/**
 * Created by e on 29/07/17.
 */
public interface ICollectibleAttribute {
    Map<String, String> getAttributes();
}
