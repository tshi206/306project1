package Graph.Interfaces;

/**
 * Created by e on 28/07/17.
 */
public interface IHasCost {
    int getCost();
}
